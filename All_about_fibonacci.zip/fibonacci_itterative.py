import os
import psutil

def fib(n):

    a = 0
    b =1

    if n < 0:
        print("number entered is not valid")
    
    elif n==0:
        print(a)

    elif n>=1:
        print(a)
        print(b)

        for i in range(1,n):
            c = a + b
            a = b
            b = c
            print(c)
    

import time

start = time.time()

n = int(input("enter the n.o of fibonacci to be generated:"))
fib(n)

process = psutil.Process(os.getpid())
print(f"Total memory : {process.memory_info().rss}") 

end = time.time()
print(f"time taken: {end - start}")


    
