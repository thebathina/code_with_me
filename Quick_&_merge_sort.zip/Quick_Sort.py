import time
import os
import psutil
def partition(arr,low,high): 
	i = ( low-1 )		 # index of smaller element 
	pivot = arr[high]	 # pivot 

	for j in range(low , high): 

		# If current element is smaller than the pivot 
		if arr[j] < pivot: 
		
			# increment index of smaller element 
			i = i+1
			arr[i],arr[j] = arr[j],arr[i] 

	arr[i+1],arr[high] = arr[high],arr[i+1] 
	return ( i+1 ) 

 
# Function to do Quick sort 
def quickSort(arr,low,high): 
	if low < high: 

		# pi is partitioning index, arr[p] is now 
		# at right place 
		pi = partition(arr,low,high) 

		# Separately sort elements before 
		# partition and after partition 
		quickSort(arr, low, pi-1) 
		quickSort(arr, pi+1, high) 

 
arr = []
n = int(input("Enter number of elements : "))
print("Enter elements one by one")
for i in range(0, n): 
    ele = float(input()) 
  
    arr.append(ele) # adding the element 
      
print(arr)  

start = time.time()

quickSort(arr,0,n-1) 
print ("Sorted array is:") 
for i in range(n): 
	print ("%0.2f" %arr[i]), 


process = psutil.Process(os.getpid())
print(f"Total memory : {process.memory_info().rss}") 

end = time.time()
print(f"time taken: {end - start}")