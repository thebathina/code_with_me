x = int(input("Enter first number:-"))
y = int(input("Enter second number:-"))

temp = x 
x = y 
y = temp 
  
print("Value of x:", x) 
print("Value of y:", y) 