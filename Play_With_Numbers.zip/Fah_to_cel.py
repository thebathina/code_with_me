 
def Fah_to_cel(n): 
	return(n - 32.0) * 5.0 / 9.0

n = 98.7
x = Fah_to_cel(n) 
print (x) 


